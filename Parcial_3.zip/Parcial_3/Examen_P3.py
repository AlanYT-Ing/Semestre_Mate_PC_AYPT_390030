import numpy as np
import matplotlib.pyplot as plt

# =========================================================
# MÉTODO RUNGE-KUTTA DE 4TO ORDEN
# COMPARACIÓN CON LTSPICE
# =========================================================

# ---------------------------------------------------------
# 1. SISTEMA DE ECUACIONES DIFERENCIALES
# ---------------------------------------------------------

def f1(t, i1, i3):
    return -20*i1 + 10*i3 + 100

def f3(t, i1, i3):
    return 10*i1 - 20*i3


# ---------------------------------------------------------
# 2. PARÁMETROS DEL PROBLEMA
# ---------------------------------------------------------

t0 = 0.0
t_final = 5.0
h = 0.1

# Condiciones iniciales
i1_0 = 0.0
i3_0 = 0.0

# Vector de tiempo
t_rk4 = np.arange(t0, t_final + h, h)

# Arreglos de resultados
i1_rk4 = np.zeros(len(t_rk4))
i3_rk4 = np.zeros(len(t_rk4))

# Valores iniciales
i1_rk4[0] = i1_0
i3_rk4[0] = i3_0


# ---------------------------------------------------------
# 3. MÉTODO RK4
# ---------------------------------------------------------

for n in range(len(t_rk4) - 1):

    t = t_rk4[n]

    i1 = i1_rk4[n]
    i3 = i3_rk4[n]

    # k1
    k1_i1 = f1(t, i1, i3)
    k1_i3 = f3(t, i1, i3)

    # k2
    k2_i1 = f1(
        t + h/2,
        i1 + (h/2)*k1_i1,
        i3 + (h/2)*k1_i3
    )

    k2_i3 = f3(
        t + h/2,
        i1 + (h/2)*k1_i1,
        i3 + (h/2)*k1_i3
    )

    # k3
    k3_i1 = f1(
        t + h/2,
        i1 + (h/2)*k2_i1,
        i3 + (h/2)*k2_i3
    )

    k3_i3 = f3(
        t + h/2,
        i1 + (h/2)*k2_i1,
        i3 + (h/2)*k2_i3
    )

    # k4
    k4_i1 = f1(
        t + h,
        i1 + h*k3_i1,
        i3 + h*k3_i3
    )

    k4_i3 = f3(
        t + h,
        i1 + h*k3_i1,
        i3 + h*k3_i3
    )

    # Actualización RK4
    i1_rk4[n+1] = i1 + (h/6) * (
        k1_i1 + 2*k2_i1 + 2*k3_i1 + k4_i1
    )

    i3_rk4[n+1] = i3 + (h/6) * (
        k1_i3 + 2*k2_i3 + 2*k3_i3 + k4_i3
    )


# ---------------------------------------------------------
# 4. RESULTADOS NUMÉRICOS
# ---------------------------------------------------------

print("================================================")
print("RESULTADOS NUMÉRICOS CON RK4")
print("================================================")

for tiempo in [0.1, 0.2, 0.3, 0.4, 0.5]:

    indice = np.where(np.isclose(t_rk4, tiempo))[0][0]

    print(f"\nTiempo = {tiempo:.1f} s")

    print(f"i1({tiempo:.1f}) = {i1_rk4[indice]:.4f} A")
    print(f"i3({tiempo:.1f}) = {i3_rk4[indice]:.4f} A")


# ---------------------------------------------------------
# 5. CARGAR DATOS DE LTSPICE
# ---------------------------------------------------------

nombre_archivo = r'C:\Users\alanp\Downloads\LTSPICE.txt'

try:

    # Leer archivo ignorando errores
    datos_lt = np.genfromtxt(
        nombre_archivo,
        skip_header=1,
        invalid_raise=False
    )

    # Eliminar filas con NaN
    datos_lt = datos_lt[
        ~np.isnan(datos_lt).any(axis=1)
    ]

    # =====================================================
    # COLUMNAS DEL ARCHIVO
    # =====================================================
    # Columna 0 -> tiempo
    # Columna 1 -> i1
    # Columna 2 -> i3
    # Columna 3 -> Ir
    # =====================================================

    t_lt  = datos_lt[:, 0]
    i1_lt = datos_lt[:, 1]
    i3_lt = datos_lt[:, 2]
    ir_lt = datos_lt[:, 3]

except Exception as e:

    print("\nERROR AL CARGAR EL ARCHIVO:")
    print(e)

    exit()


# ---------------------------------------------------------
# 6. INTERPOLACIÓN
# ---------------------------------------------------------

i1_lt_interp = np.interp(
    t_rk4,
    t_lt,
    i1_lt
)

i3_lt_interp = np.interp(
    t_rk4,
    t_lt,
    i3_lt
)


# ---------------------------------------------------------
# 7. ERROR ABSOLUTO
# ---------------------------------------------------------

error_i1 = np.abs(i1_lt_interp - i1_rk4)
error_i3 = np.abs(i3_lt_interp - i3_rk4)


# ---------------------------------------------------------
# 8. MOSTRAR ERRORES
# ---------------------------------------------------------

print("\n================================================")
print("ERRORES ABSOLUTOS")
print("================================================")

for tiempo in [0.1, 0.2, 0.3, 0.4, 0.5]:

    indice = np.where(np.isclose(t_rk4, tiempo))[0][0]

    print(f"\nTiempo = {tiempo:.1f} s")

    print(f"Error i1 = {error_i1[indice]:.4f} A")
    print(f"Error i3 = {error_i3[indice]:.4f} A")


# ---------------------------------------------------------
# 9. GRÁFICAS
# ---------------------------------------------------------

fig, (ax1, ax2) = plt.subplots(
    2,
    1,
    figsize=(12, 8)
)

# =========================================================
# GRÁFICA 1
# COMPARACIÓN
# =========================================================

# i1 LTSpice
ax1.plot(
    t_lt,
    i1_lt,
    color='blue',
    linewidth=2,
    label='i1 LTSpice'
)

# i1 RK4
ax1.plot(
    t_rk4,
    i1_rk4,
    'bo--',
    markersize=5,
    label='i1 RK4'
)

# i3 LTSpice
ax1.plot(
    t_lt,
    i3_lt,
    color='red',
    linewidth=2,
    label='i3 LTSpice'
)

# i3 RK4
ax1.plot(
    t_rk4,
    i3_rk4,
    'ro--',
    markersize=5,
    label='i3 RK4'
)

# Ir LTSpice
ax1.plot(
    t_lt,
    ir_lt,
    color='green',
    linewidth=2,
    label='Ir LTSpice'
)

ax1.set_title(
    'Comparación de Resultados: LTSpice vs RK4',
    fontsize=15
)

ax1.set_ylabel(
    'Corriente (A)',
    fontsize=12
)

ax1.grid(
    True,
    linestyle='--',
    alpha=0.7
)

ax1.legend()

ax1.set_xlim(0, 0.5)
ax1.set_ylim(-5, 15)


# =========================================================
# GRÁFICA 2
# ERROR ABSOLUTO
# =========================================================

ax2.plot(
    t_rk4,
    error_i1,
    'bo-',
    markersize=5,
    label='Error Absoluto i1'
)

ax2.plot(
    t_rk4,
    error_i3,
    'ro-',
    markersize=5,
    label='Error Absoluto i3'
)

ax2.set_title(
    'Error Absoluto de Truncamiento',
    fontsize=15
)

ax2.set_xlabel(
    'Tiempo (s)',
    fontsize=12
)

ax2.set_ylabel(
    'Error (A)',
    fontsize=12
)

ax2.grid(
    True,
    linestyle='--',
    alpha=0.7
)

ax2.legend()

ax2.set_xlim(0, 0.5)
ax2.set_ylim(0, 10)


# ---------------------------------------------------------
# 10. MOSTRAR GRÁFICAS
# ---------------------------------------------------------

plt.tight_layout()

plt.show()