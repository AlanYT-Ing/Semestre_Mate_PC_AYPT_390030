import numpy as np
import matplotlib.pyplot as plt
import math
import cmath

# Definimos la función
def f(x):
    return x**2 - 2*x + 5

# ==========================================
# MÉTODO DE BISECCIÓN
# ==========================================
def biseccion(funcion, a, b, tol=1e-5, max_iter=100):
    # Validamos que exista un cambio de signo en el intervalo
    if funcion(a) * funcion(b) >= 0:
        print(f"Bisección - Error: No hay cambio de signo en el intervalo [{a}, {b}].")
        return None
    
    c = a
    for iteracion in range(max_iter):
        c = (a + b) / 2.0
        
        # Condición de parada: encontramos la raíz exacta o alcanzamos la tolerancia
        if funcion(c) == 0 or (b - a) / 2.0 < tol:
            print(f"Bisección - Raíz encontrada en x = {c} (Iteraciones: {iteracion+1})")
            return c
            
        # Redefinimos el intervalo
        if np.sign(funcion(c)) == np.sign(funcion(a)):
            a = c
        else:
            b = c
            
    print("Bisección - Se alcanzó el número máximo de iteraciones sin converger.")
    return c

# ==========================================
# MÉTODO DE REGLA FALSA
# ==========================================
def regla_falsa(funcion, a, b, tol=1e-5, max_iter=100):
    # Validamos que exista un cambio de signo en el intervalo
    if funcion(a) * funcion(b) >= 0:
        print(f"Regla Falsa - Error: No hay cambio de signo en el intervalo [{a}, {b}].")
        return None
    
    c = a
    for iteracion in range(max_iter):
        # Fórmula de la regla falsa
        c = b - (funcion(b) * (a - b)) / (funcion(a) - funcion(b))
        
        # Condición de parada
        if abs(funcion(c)) < tol:
            print(f"Regla Falsa - Raíz encontrada en x = {c} (Iteraciones: {iteracion+1})")
            return c
            
        # Redefinimos el intervalo
        if np.sign(funcion(a)) * np.sign(funcion(c)) < 0:
            b = c
        else:
            a = c
            
    print("Regla Falsa - Se alcanzó el número máximo de iteraciones sin converger.")
    return c

# ==========================================
# EJECUCIÓN Y GRÁFICA
# ==========================================

# Intentamos ejecutar los métodos con un intervalo aleatorio (ej. -5 a 5)
print("Intentando encontrar raíces reales para f(x) = x^2 - 2x + 5:\n")
raiz_bis = biseccion(f, -5, 5)
raiz_rf = regla_falsa(f, -5, 5)

# Graficamos la función para visualizar por qué fallan los métodos
x = np.linspace(-3, 5, 400)
y = f(x)

plt.figure(figsize=(8, 5))
plt.plot(x, y, label='f(x) = $x^2 - 2x + 5$', color='blue')
plt.axhline(0, color='black', linewidth=1.2) # Eje X
plt.axvline(0, color='black', linewidth=1.2) # Eje Y
plt.grid(True, linestyle='--', alpha=0.7)
plt.title("Gráfica de la función (Nota: Nunca cruza el eje X)")
plt.xlabel('x')
plt.ylabel('f(x)')
plt.legend()
plt.show()