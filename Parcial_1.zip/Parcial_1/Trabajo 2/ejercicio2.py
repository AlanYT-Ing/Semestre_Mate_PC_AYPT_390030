import numpy as np
import matplotlib.pyplot as plt 

def reglafalsa(f, x0, x1, tol=1e-8, max_iter=1000):
    # Verifica cambio de signo en el intervalo
    if f(x0) * f(x1) > 0:
        raise ValueError("La función no cambia de signo en este rango")

    print("{:^10s} {:^10s} {:^10s} {:^10s} {:^10s} {:^10s}".format(
        "x0", "x", "x1", "f(x0)", "f(x)", "f(x1)"
    ))

    for _ in range(max_iter):
        # Fórmula de regla falsa
        x = (x0 * f(x1) - x1 * f(x0)) / (f(x1) - f(x0))

        print("{:10.5f} {:10.5f} {:10.5f} {:10.5f} {:10.5f} {:10.5f}".format(
            x0, x, x1, f(x0), f(x), f(x1)
        ))

        # Criterio de paro
        if abs(f(x)) < tol:
            return x

        # Actualiza intervalo conservando el cambio de signo
        if f(x0) * f(x) < 0:
            x1 = x
        else:
            x0 = x

    raise RuntimeError("No convergió en el número máximo de iteraciones")


def f(x):
    return -0.5 * x**2 + 2.5 * x + 4.5


def main():
    x0 = 6
    x1 = 7

    raiz = reglafalsa(f, x0, x1)
    print("Raíz aproximada:", raiz)

    #  vector para graficar
    x = np.linspace(x0, x1, 200)
    y = f(x)  # era X, debe ser x

    plt.figure()
    plt.plot(x, y, label="f(x)")
    plt.scatter(raiz, f(raiz), zorder=3)
    plt.text(raiz, f(raiz), "  Raíz " + str(raiz), color="red")
    plt.axhline(0)  # línea y=0 para ver el cruce
    plt.grid(True)
    plt.legend()
    plt.show()


if __name__ == "__main__":
    main()
