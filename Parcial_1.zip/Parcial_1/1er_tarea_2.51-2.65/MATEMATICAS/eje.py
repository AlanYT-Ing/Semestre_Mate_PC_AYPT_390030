import math

def reglafalsa(f, x0, x1, tol=1e-8, max_iter=200):
    """
    Método de la Regla Falsa (Falsa Posición).
    Detiene cuando |f(x)| < tol o cuando se alcanza max_iter.
    Imprime tabla por iteración.
    """
    f0 = f(x0)
    f1 = f(x1)

    if f0 * f1 > 0:
        raise ValueError("La función no cambia de signo en el intervalo dado. Elige otro [x0, x1].")

    print("{:^4s} {:^12s} {:^12s} {:^12s} {:^14s} {:^14s} {:^14s}".format(
        "it", "x0", "x", "x1", "f(x0)", "f(x)", "f(x1)"
    ))

    x = None
    for it in range(1, max_iter + 1):
        # Fórmula de interpolación lineal
        x = (x0 * f1 - x1 * f0) / (f1 - f0)
        fx = f(x)

        print("{:>4d} {:>12.6f} {:>12.6f} {:>12.6f} {:>14.6f} {:>14.6f} {:>14.6f}".format(
            it, x0, x, x1, f0, fx, f1
        ))

        # Criterio de paro
        if abs(fx) < tol:
            return x, it

        # Actualización del intervalo (conserva el cambio de signo)
        if f0 * fx < 0:
            x1 = x
            f1 = fx
        else:
            x0 = x
            f0 = fx

    return x, max_iter


# ============================================================
# Ejemplo 3.3: Tanque esférico
# V = pi*h^2*(3R - h)/3 , con R = 10, V = 800
# ============================================================
def main():
    R = 10.0
    V_obj = 800.0

    def f(h):
        return (math.pi * h**2 * (3*R - h) / 3.0) - V_obj

    # Intervalo donde sí hay cambio de signo (para este caso: [5, 6])
    x0, x1 = 5.0, 6.0

    raiz, iters = reglafalsa(f, x0, x1, tol=1e-8, max_iter=200)

    V_calc = math.pi * raiz**2 * (3*R - raiz) / 3.0
    print("\nResultado:")
    print(f"h ≈ {raiz:.10f} (en {iters} iteraciones)")
    print(f"Volumen con esa h: V(h) ≈ {V_calc:.10f}")
    print(f"Error vs 800: {abs(V_calc - V_obj):.3e}")

if __name__ == "__main__":
    main()
