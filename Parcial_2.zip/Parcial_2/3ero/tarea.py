# Ejercicio 1
import numpy as np

# Definir las matrices
A = np.array([[1, -2, 3],
              [2, 1, 4],
              [3, -1, -2]])

B = np.array([[0, 4, 2],
              [3, -1, -3]])

C = np.array([[-2, 1],
              [0, -1],
              [1, 3]])

D = np.array([[1, -3, 0],
              [2, -2, 2],
              [3, -1, 1]])

#Imprimir las matrices
print("Matriz A:")
print(A)
print("Matriz B:")
print(B)
print("Matriz C:")
print(C)
print("Matriz D:")
print(D)

# Suma A + D
S = A + D
print("Suma de las matrices A y D:")
print(S)

# Resta D - A
e = D - A
print("Resta de las matrices D - A:")
print(e)

# Multiplicación por escalar
E = 3 * B
print("Multiplicación de la matriz B por el escalar 3:")
print(E)

# A + B (NO definida)
print("Suma de las matrices A y B:")
print("No definida (dimensiones diferentes)")

# Multiplicación matricial A @ D
G = np.dot(A, D)
print("Multiplicación de las matrices A y D:")
print(G)

# Multiplicación matricial A @ C (NO definida)
print("Multiplicación de las matrices A y C:")
print("No definida (dimensiones incompatibles)")

# División elemento a elemento A / D
I = np.divide(A, D)
print("División de las matrices A y D:")
print(I)

# A / B (NO definida)
print("División de las matrices A y B:")
print("No definida (dimensiones diferentes)")

# Multiplicación elemento a elemento A * D
K = np.multiply(A, D)
print("Multiplicación estándar de las matrices A y D:")
print(K)

# A * B (NO definida)
print("Multiplicación estándar de las matrices A y B:")
print("No definida (dimensiones diferentes)")

# Multiplicación matricial B @ C
M = np.dot(B, C)
print("Multiplicación matricial de la matriz B y C:")
print(M)

# Ejercicio 2

#Encontrar la inversa de la Matriz A con 3 decimales y que aparezca A^-1
A_inv = np.linalg.inv(A)
A_inv_rounded = np.round(A_inv, 3)
print("Inversa de la matriz A (A^-1):")
print(A_inv_rounded)

# Ejercicio 3

#Indicar cual de las siguientes ecuaciones es lineal, desde a hasta f
print("Ecuación a: 2x - y = 7")
print("Ecuación b: 3x -4 +2z = 3y")
print("Ecuación c: 4√x - 2y = 10")
print("Ecuación d: 2/x - 4y + z = 6")
print("Ecuación e: 3xy - 2y + z = 4")
print("Ecuación f: -x + 3y -sin(z)= 2")
#Indicar cuales son lineales mediante código
def is_linear(equation):
    # Verificar si la ecuación es lineal
    if 'x^2' in equation or 'y^2' in equation or 'z^2' in equation or 'sin' in equation or 'e^' in equation:
        return False
    return True
equations = ['2x - y = 7', ' 3x -4 +2z = 3y', '4√x - 2y = 10', '2/x - 4y + z = 6', '3xy - 2y + z = 4', '-x + 3y -sin(z)= 2']
for eq in equations:
    if is_linear(eq):
        print(f"La ecuación '{eq}' es lineal.")
    else:
        print(f"La ecuación '{eq}' no es lineal.")

# Ejercicio de sistema de ecuaciones 2x2 sin matrices, sin array por método de sustitución
# Sistema de ecuaciones:
# 2x - y = 5
# 3x + 2y = 4

print("Sistema de ecuaciones:")
print("2x - y = 5")
print("3x + 2y = 4")

# Método de sustitución:
# De 2x - y = 5  ->  y = 2x - 5
# Sustituyendo en 3x + 2y = 4:
# 3x + 2(2x - 5) = 4  ->  7x = 14  ->  x = 14/7
x = 14 / 7
y = 2*x - 5

print(f"Solución del sistema de ecuaciones: x = {x}, y = {y}")

#Ultimo ejercicio.

# Sistema:
# x - 3y + 2z - w  = 6
# 2x - 4y + 5z + 2w = 13
# -x + 3y - z + 3w = -23
# 3x + 2y - z - w  = 6

A = np.array([
    [ 1, -3,  2, -1],
    [ 2, -4,  5,  2],
    [-1,  3, -1,  3],
    [ 3,  2, -1, -1]
], dtype=float)

b = np.array([6, 13, -23, 6], dtype=float)

x, y, z, w = np.linalg.solve(A, b)

print(f"x = {x:.0f}, y = {y:.0f}, z = {z:.0f}, w = {w:.0f}")