#Matriz 5x5
import numpy as np
np.set_printoptions(precision=2, suppress=1, floatmode="fixed")

A = np.array([[1,2,3,4,5], [-2,4,-3,5,1], [-1,3,-3,4,2], [0,-1,2,-4,3], [5,0,-2,1,-1]])
print ("A = ")
print(A)
B = np.array([[2,1,0,3,4], [1,-2,5,-1,0], [3,0,-1,2,-4], [-2,4,1,-3,5], [0,-1,2,4,-3]])
print ("B = ")
print(B)

#Obtenemos el tamaño de A
m,n = np.shape(A)
print("filas = {}, columnas = {}" .format(m,n))

#Obtenemos el tamaño de B
p,q = np.shape(B)
print("filas = {}, columnas = {}" .format(p,q))

#Aplicamos algebra lineal a las matrices A y B
print("Suma de A y B:")
print(A + B)
print("Producto de A y B:")
print(np.dot(A, B))

#Seguimos con las operaciones
print("Transpuesta de A:")
print(A.T)
print("Inversa de A:")
print(np.linalg.inv(A))

print("Transpuesta de B:")
print(B.T)
print("Inversa de B:")
print(np.linalg.inv(B))

#calculamos el determinante de A y B
print("Determinante de A:")
print(np.linalg.det(A))
print("Determinante de B:")
print(np.linalg.det(B))

#Resolvemos el sistema para A y B
print("Solución de A:")
print(np.linalg.solve(A, np.array([1,2,3,4,5])))
print("Solución de B:")
print(np.linalg.solve(B, np.array([2,1,0,3,4])))

#Imprimimos una despedida
print("¡Gracias por usar este programa!")
