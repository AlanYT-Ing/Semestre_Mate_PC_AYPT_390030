
import numpy as np

T = np.arange(300, 2001, 100, dtype=float)
e_tab = np.array([
    0.024,0.035,0.046,0.058,0.067,0.083,0.097,0.111,0.125,
    0.140,0.155,0.170,0.186,0.202,0.219,0.235,0.252,0.269
], dtype=float)

def corr(T):
    return 0.02424*(T/303.16)**1.27591

mid = np.arange(350, 1951, 100, dtype=float)

def local_nodes(x0, deg):
    idx = np.argsort(np.abs(T - x0))[:deg+1]
    return np.sort(idx)

def interp(x0, deg):
    idx = local_nodes(x0, deg)
    c = np.polyfit(T[idx], e_tab[idx], deg)
    return np.polyval(c, x0)

for deg in range(1, 7):
    ok = True
    max_err = 0.0
    for xm in mid:
        val = interp(xm, deg)
        err = abs(val - corr(xm))
        max_err = max(max_err, err)
        if round(val, 3) != round(corr(xm), 3):
            ok = False
    print(f"Grado {deg}: max error = {max_err:.6f}, coincide a 3 decimales? {ok}")
