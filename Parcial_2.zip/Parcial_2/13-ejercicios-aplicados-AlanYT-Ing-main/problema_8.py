
import sympy as sp
import math
import numpy as np

x = sp.symbols('x')
a,b,c,d = sp.symbols('a b c d')
P = a*x**3 + b*x**2 + c*x + d

# Datos Hermite
sol = sp.solve([
    sp.Eq(P.subs(x,1), sp.E),
    sp.Eq(sp.diff(P,x).subs(x,1), 0),
    sp.Eq(P.subs(x,3), sp.E**3/3),
    sp.Eq(sp.diff(P,x).subs(x,3), 2*sp.E**3/9),
], [a,b,c,d])

H = sp.expand(P.subs(sol))
print("Polinomio de Hermite:")
print(H)

f = lambda t: math.exp(t)/t
pts = [1.5, 2.0, 2.5]
print("\nValores con Hermite:")
for t in pts:
    val = float(H.subs(x, t))
    print(t, val, f(t), val - f(t))

# Comparacion con cubico interpolante en x=1,1.5,2.4,3
xi = np.array([1.0, 1.5, 2.4, 3.0], dtype=float)
yi = np.array([f(v) for v in xi], dtype=float)
coeff = np.polyfit(xi, yi, 3)

print("\nValores con cubico interpolante ordinario:")
for t in pts:
    val = float(np.polyval(coeff, t))
    print(t, val, f(t), val - f(t))
