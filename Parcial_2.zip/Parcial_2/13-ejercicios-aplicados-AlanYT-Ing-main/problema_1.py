
"""
Problema 1.
Resumen conceptual sobre los polinomios de Newton-Gregory, Gauss, Stirling y Bessel.

Este archivo no hace computo numerico; resume las diferencias de uso:
- Newton-Gregory hacia adelante: conveniente cerca del inicio de la tabla.
- Newton-Gregory hacia atras: conveniente cerca del final de la tabla.
- Gauss hacia adelante / atras: conveniente cerca del centro.
- Stirling: promedio simetrico de formulas centrales, util cuando el punto esta muy cerca del centro.
- Bessel: util cuando el punto esta entre dos nodos centrales.
"""
print(__doc__)
