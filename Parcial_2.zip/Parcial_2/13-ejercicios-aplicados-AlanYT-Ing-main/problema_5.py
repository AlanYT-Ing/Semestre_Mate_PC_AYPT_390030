
import numpy as np
from scipy.interpolate import CubicSpline

x = np.array([0,0.5,1.0,1.5,2.0,3.0,3.5,4.0], dtype=float)
y = np.array([1.90,2.39,2.71,2.98,3.20,3.20,2.98,2.74], dtype=float)
x0 = 2.5

# Estimaciones varias
linear = np.interp(x0, [2.0, 3.0], [3.20, 3.20])
quad = np.polyval(np.polyfit([1.5,2.0,3.0],[2.98,3.20,3.20], 2), x0)
cubic = np.polyval(np.polyfit([1.5,2.0,3.0,3.5],[2.98,3.20,3.20,2.98], 3), x0)
spline = CubicSpline(x, y, bc_type="natural")(x0)

print("Estimacion lineal:", float(linear))
print("Estimacion cuadratica:", float(quad))
print("Estimacion cubica local:", float(cubic))
print("Estimacion spline cubico natural:", float(spline))
