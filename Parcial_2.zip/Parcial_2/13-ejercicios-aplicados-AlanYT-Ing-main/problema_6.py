
import numpy as np
from scipy.interpolate import CubicSpline

N = np.array([0.0521,0.1028,0.2036,0.4946,0.9863,1.9739,2.443,5.06], dtype=float)
D = np.array([1.65,2.10,2.27,2.76,3.12,3.06,2.92,2.07], dtype=float)

spline = CubicSpline(N, D, bc_type="natural")

print("Tabla pedida")
for n in range(0, 6):
    print(f"N={n}: D  {float(spline(n)):.6f} (x10^6 cm^2/s)")
