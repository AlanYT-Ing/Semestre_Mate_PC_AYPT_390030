
import numpy as np

xg = np.array([0.0,0.5,1.0,1.5,2.0], dtype=float)
yg = np.array([0.0,0.5,1.0,1.5,2.0,2.5], dtype=float)

u = np.array([
    [0.0,5.00,10.00,15.00,20.00,25.00],
    [5.00,7.51,10.05,12.70,15.67,20.00],
    [10.00,10.00,10.00,10.00,10.00,10.00],
    [15.00,12.51,9.95,7.32,4.33,0.00],
    [20.00,15.00,10.00,5.00,0.00,-5.00]
], dtype=float)

def bilinear(x, y):
    i = np.searchsorted(xg, x) - 1
    j = np.searchsorted(yg, y) - 1
    i = max(0, min(i, len(xg)-2))
    j = max(0, min(j, len(yg)-2))
    x1, x2 = xg[i], xg[i+1]
    y1, y2 = yg[j], yg[j+1]
    Q11 = u[i, j]
    Q21 = u[i+1, j]
    Q12 = u[i, j+1]
    Q22 = u[i+1, j+1]
    return (
        Q11*(x2-x)*(y2-y) + Q21*(x-x1)*(y2-y)
        + Q12*(x2-x)*(y-y1) + Q22*(x-x1)*(y-y1)
    ) / ((x2-x1)*(y2-y1))

puntos = [(0.7,1.2), (1.6,2.4), (0.65,0.82)]
for p in puntos:
    print(p, bilinear(*p))
