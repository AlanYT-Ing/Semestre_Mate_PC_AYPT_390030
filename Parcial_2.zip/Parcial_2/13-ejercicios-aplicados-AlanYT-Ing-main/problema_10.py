
import numpy as np
from scipy.interpolate import CubicSpline

# Datos principales
phase = np.array([-110,-80,-40,-10,30,80,110], dtype=float)
mag = np.array([7.98,8.95,10.71,11.70,10.01,8.23,7.86], dtype=float)

# Construccion periodica: periodo 240 y repeticion del primer nodo
xp = np.array([10,40,80,110,150,200,230,250], dtype=float)
yp = np.array([7.98,8.95,10.71,11.70,10.01,8.23,7.86,7.98], dtype=float)

spline = CubicSpline(xp, yp, bc_type="periodic")

obs_phase = np.array([-100,-60,-20,20,60,100], dtype=float)
obs_mag = np.array([8.37,9.40,11.39,10.84,8.53,7.89], dtype=float)

def eval_phase(p):
    pp = (p + 120) % 240
    if pp < 10:
        pp += 240
    return float(spline(pp))

pred = np.array([eval_phase(p) for p in obs_phase])
err = pred - obs_mag

for p, yhat, y, e in zip(obs_phase, pred, obs_mag, err):
    print(f"fase={p:6.1f}, spline={yhat:.6f}, dato={y:.6f}, error={e:+.6f}")

print("\nRMSE =", float(np.sqrt(np.mean(err**2))))
print("Error maximo absoluto =", float(np.max(np.abs(err))))
