# ==========================================
# Problema 12 - Applied Numerical Analysis
# Recalculo de tabla de diferencias
# cuando f(0.36) cambia de 0.74371 a 0.73471
# ==========================================

def tabla_diferencias(x, y):
    """
    Construye la tabla completa de diferencias hacia adelante.
    Regresa una lista de listas.
    """
    n = len(y)
    tabla = [y[:]]  # primera columna: f(x)

    for k in range(1, n):
        col = []
        for i in range(n - k):
            diferencia = tabla[k - 1][i + 1] - tabla[k - 1][i]
            col.append(diferencia)
        tabla.append(col)

    return tabla


def imprimir_tabla(x, tabla):
    """
    Imprime la tabla de diferencias con formato.
    """
    n = len(x)

    encabezados = ["x", "f(x)"]
    for i in range(1, n):
        encabezados.append(f"Δ^{i}f" if i > 1 else "Δf")

    # imprimir encabezados
    print("-" * 100)
    print("{:<10}".format(encabezados[0]), end="")
    for h in encabezados[1:]:
        print("{:<15}".format(h), end="")
    print()
    print("-" * 100)

    # imprimir filas
    for i in range(n):
        print("{:<10.2f}".format(x[i]), end="")
        for j in range(n - i):
            print("{:<15.5f}".format(tabla[j][i]), end="")
        print()

    print("-" * 100)


def comparar_tablas(tabla_original, tabla_nueva):
    """
    Compara las diferencias entre la tabla original y la nueva.
    """
    print("\nComparación de cambios:")
    print("-" * 60)

    for orden in range(len(tabla_original)):
        for i in range(len(tabla_original[orden])):
            cambio = tabla_nueva[orden][i] - tabla_original[orden][i]
            if abs(cambio) > 1e-12:
                if orden == 0:
                    nombre = f"f[{i}]"
                elif orden == 1:
                    nombre = f"Δf[{i}]"
                else:
                    nombre = f"Δ^{orden}f[{i}]"

                print(f"{nombre:<12} : {tabla_original[orden][i]:>10.5f} -> {tabla_nueva[orden][i]:>10.5f}   cambio = {cambio:+.5f}")


# ==========================================
# Datos originales del ejercicio 30
# ==========================================
x = [0.12, 0.24, 0.36, 0.48, 0.60, 0.72]
y_original = [0.79168, 0.77334, 0.74371, 0.70413, 0.65632, 0.60228]

# Datos con error en x = 0.36
y_error = [0.79168, 0.77334, 0.73471, 0.70413, 0.65632, 0.60228]

# Construcción de tablas
tabla_original = tabla_diferencias(x, y_original)
tabla_nueva = tabla_diferencias(x, y_error)

# Mostrar tablas
print("\nTABLA ORIGINAL")
imprimir_tabla(x, tabla_original)

print("\nTABLA MODIFICADA (con f(0.36) = 0.73471)")
imprimir_tabla(x, tabla_nueva)

# Comparar cambios
comparar_tablas(tabla_original, tabla_nueva)