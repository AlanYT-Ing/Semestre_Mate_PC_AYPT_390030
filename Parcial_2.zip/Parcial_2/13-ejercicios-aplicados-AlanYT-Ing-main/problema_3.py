
import numpy as np
from scipy.interpolate import CubicSpline

# Datos completos APP2
x = np.array([1985,1986,1987,1988,1989,1990,1991,1992,1993,1994,1995], dtype=float)
y = np.array([731,782,833,886,956,1049,1159,1267,1367,1436,1505], dtype=float)

# Enfoques para extrapolar hacia 1980
p1 = np.polyfit(x, y, 1)
p2 = np.polyfit(x, y, 2)
p3_ls = np.polyfit(x, y, 3)
s = CubicSpline(x, y, bc_type="natural")

# Cubico interpolante local con los cuatro primeros puntos
p3_local = np.polyfit(x[:4], y[:4], 3)

year = 1980
print("Estimaciones para 1980")
print("Cubico local 1985-1988:", float(np.polyval(p3_local, year)))
print("Recta minimos cuadrados:", float(np.polyval(p1, year)))
print("Cuadratico minimos cuadrados:", float(np.polyval(p2, year)))
print("Cubico minimos cuadrados:", float(np.polyval(p3_ls, year)))
print("Spline cubico natural:", float(s(year)))
print("Valor historico dado en el enunciado:", 492.0)
