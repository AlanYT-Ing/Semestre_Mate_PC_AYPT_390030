
import numpy as np
from scipy.interpolate import CubicSpline

# Datos 1991-1994
x = np.array([1991, 1992, 1993, 1994], dtype=float)
y = np.array([1159, 1267, 1367, 1436], dtype=float)

# Ajustes y extrapolaciones
p3 = np.polyfit(x, y, 3)
p1 = np.polyfit(x, y, 1)
p2 = np.polyfit(x, y, 2)
s = CubicSpline(x, y, bc_type="natural")

for year in [1995, 2000]:
    print(f"\nEstimaciones para {year}")
    print("Cubico interpolante:", float(np.polyval(p3, year)))
    print("Recta minimos cuadrados:", float(np.polyval(p1, year)))
    print("Cuadratico minimos cuadrados:", float(np.polyval(p2, year)))
    print("Spline cubico natural:", float(s(year)))
