import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline

# ==========================================
# Problema 9 - APP9
# Basado en los ejercicios 43 y 44
# ==========================================

# Funcion original del ejercicio 43
def f(x):
    x = np.asarray(x)
    y = np.zeros_like(x, dtype=float)

    mask1 = (-1 <= x) & (x <= 1)
    mask2 = (1 <= x) & (x <= 2)
    mask3 = (2 <= x) & (x <= 4)

    y[mask1] = 1 - x[mask1]
    y[mask2] = 2 * (x[mask2] - 1)
    y[mask3] = (x[mask3] + 2) / 2

    return y

# Nodos del ejercicio 44
x_nodes = np.array([-1.0, 1.0, 2.0, 4.0])
y_nodes = np.array([2.0, 0.0, 2.0, 3.0])

# Spline cubico natural
cs = CubicSpline(x_nodes, y_nodes, bc_type='natural')

# Mallado fino
x_plot = np.linspace(-1, 4, 1000)
y_true = f(x_plot)
y_spline = cs(x_plot)

# Error maximo
error = np.abs(y_true - y_spline)
max_error = np.max(error)
x_max_error = x_plot[np.argmax(error)]

print("=== Problema 9 ===")
print("Nodos usados:", list(zip(x_nodes, y_nodes)))
print(f"Error maximo = {max_error:.6f}")
print(f"Ocurre aproximadamente en x = {x_max_error:.6f}")

# Mostrar ecuaciones por intervalo
coef = cs.c  # forma: c[0]*(x-xi)^3 + c[1]*(x-xi)^2 + c[2]*(x-xi) + c[3]

for i in range(len(x_nodes) - 1):
    print(f"\nIntervalo [{x_nodes[i]}, {x_nodes[i+1]}]:")
    print("S(x) = "
          f"{coef[0,i]:.8f}(x-{x_nodes[i]})^3 + "
          f"{coef[1,i]:.8f}(x-{x_nodes[i]})^2 + "
          f"{coef[2,i]:.8f}(x-{x_nodes[i]}) + "
          f"{coef[3,i]:.8f}")

# Grafica
plt.figure(figsize=(8,5))
plt.plot(x_plot, y_true, label='f(x) original', linewidth=2)
plt.plot(x_plot, y_spline, '--', label='Spline cúbico natural', linewidth=2)
plt.plot(x_nodes, y_nodes, 'o', label='Nodos')
plt.axvline(x_max_error, linestyle=':', label=f'x error máx ≈ {x_max_error:.3f}')
plt.xlabel('x')
plt.ylabel('y')
plt.title('Problema 9: comparación entre f(x) y spline cúbico')
plt.legend()
plt.grid(True)
plt.show()