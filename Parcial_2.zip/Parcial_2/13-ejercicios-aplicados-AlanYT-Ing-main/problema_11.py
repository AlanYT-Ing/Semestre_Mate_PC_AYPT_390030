import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline

t = np.array([-1, -0.96, -0.86, -0.79, 0.22, 0.5, 0.93], dtype=float)
y = np.array([-1, -0.151, 0.894, 0.986, 0.895, 0.5, -0.306], dtype=float)

# Polinomio interpolante de grado 6
p = np.poly1d(np.polyfit(t, y, 6))

# Spline cúbico natural
s = CubicSpline(t, y, bc_type="natural")

xx = np.linspace(min(t), max(t), 800)

plt.figure(figsize=(8,5))
plt.plot(t, y, 'ko', label='Datos')
plt.plot(xx, s(xx), label='Spline cúbico')
plt.plot(xx, p(xx), label='Lagrange grado 6')
plt.xlabel('t')
plt.ylabel('y')
plt.title('Problema 11')
plt.grid(True, alpha=0.3)
plt.legend()
plt.tight_layout()

# RUTA DONDE QUIERES GUARDAR
ruta = r"C:\Users\alanp\OneDrive\Pictures\Screenshots\problema_11_grafica.png"

plt.savefig(ruta, dpi=200, bbox_inches='tight')

print("Gráfica guardada en:")
print(ruta)

plt.show()
plt.close()