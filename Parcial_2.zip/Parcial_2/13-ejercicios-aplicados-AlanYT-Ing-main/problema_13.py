import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import splprep, splev

# Puntos de control
pts = np.array([
    [0.00, 8.00],
    [0.20, 8.70],
    [0.35, 9.30],
    [0.10,10.20],
    [-0.40,10.90],
    [-1.10,11.80],
    [-1.60,12.80],
    [-2.10,13.90],
    [-2.40,15.00],
    [-2.10,15.60],
    [-1.60,15.90],
    [-1.55,16.30],
    [-1.90,16.60],
    [-1.80,17.20],
    [-1.50,17.80],
    [-1.45,18.60],
    [-1.65,19.20],
    [-1.85,20.20],
    [-1.50,21.40],
    [-0.80,22.20],
    [-0.20,23.10],
    [0.15,24.10],
    [0.25,25.20],
], dtype=float)

# Spline
tck, _ = splprep([pts[:,0], pts[:,1]], s=0.2, k=3)
uu = np.linspace(0, 1, 500)
xs, ys = splev(uu, tck)

plt.figure(figsize=(4,8))
plt.plot(xs, ys, 'k-', lw=2, label='Spline del perfil')
plt.plot(pts[:,0], pts[:,1], 'ro', ms=3, label='Puntos de control')
plt.gca().set_aspect('equal', adjustable='box')
plt.gca().invert_yaxis()
plt.legend()
plt.title('Perfil aproximado del Problema 13')
plt.tight_layout()

# MISMA RUTA QUE EL PROBLEMA 11
ruta = r"C:\Users\alanp\OneDrive\Pictures\Screenshots\problema_13_perfil.png"

plt.savefig(ruta, dpi=200, bbox_inches='tight')

print("Gráfica guardada en:")
print(ruta)

plt.show()
plt.close()