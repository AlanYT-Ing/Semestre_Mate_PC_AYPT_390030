#Hacer un programa con las series de taylor
import math
def taylor_sin(x, n):
    sin_x = 0
    for k in range(n):
        sin_x += ((-1)**k * x**(2*k + 1)) / math.factorial(2*k + 1))
    return sin_x
# Ejemplo de uso
x = math.pi / 4  # Ángulo en radianes
n = 10  # Número de términos en la serie de Taylor
aproximacion = taylor_sin(x, n)
print(f"La aproximación de sin({x}) usando {n} términos es: {aproximacion}")
print(f"El valor real de sin({x}) es: {math.sin(x)}")

