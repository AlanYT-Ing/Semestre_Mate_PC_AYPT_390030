# Examen_MATEPORPC
# Alumno: Alan Yair Pérez Torres y Osvaldo Villanueva Torres
# Claves: 390030, 383628
# Fecha: 2026-04-23
# 2.- MODELADO DE RESPUESTA TRANSITORIA: AJUSTE DE SISTEMAS

import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline

# Función teórica del sistema RLC de segundo orden
def y_teorica(t):
    return 10 * (1 - np.exp(-0.8 * t) * (np.cos(2.5 * t) + 0.32 * np.sin(2.5 * t)))

def seccion2():
    # 12 puntos de muestreo dentro del intervalo [0, 6]
    # Se eligieron distribuyendo puntos en zonas donde la respuesta cambia más rápido
    # (inicio, sobreimpulso y amortiguamiento), para representar mejor la dinámica del sistema.
    t_muestra = np.array([0.00, 0.20, 0.45, 0.70, 1.00, 1.35, 1.80, 2.40, 3.10, 4.00, 5.00, 6.00])
    y_muestra = y_teorica(t_muestra)

    # Interpolación cúbica spline
    interp = CubicSpline(t_muestra, y_muestra)

    # 200 puntos equiespaciados en [0, 6]
    t_validacion = np.linspace(0, 6, 200)
    y_real = y_teorica(t_validacion)
    y_interp = interp(t_validacion)

    # Cálculo de errores
    errores = np.abs(y_real - y_interp)
    error_maximo = np.max(errores)
    mse = np.mean((y_real - y_interp) ** 2)

    # Tabla de valores
    print("Tabla de 12 puntos de muestreo")
    print(" i\t t\t\t y(t)")
    for i in range(len(t_muestra)):
        print(f"{i+1}\t {t_muestra[i]:.2f}\t\t {y_muestra[i]:.6f}")

    # Resultados
    print("\nResultados del modelo:")
    print("a) Método seleccionado: Interpolación spline cúbica")
    print("b) Error máximo:", error_maximo)
    print("c) MSE:", mse)

    # Gráfica comparativa
    plt.figure(figsize=(10, 6))
    plt.plot(t_validacion, y_real, 'r-', linewidth=2, label='Función real')
    plt.plot(t_validacion, y_interp, 'b--', linewidth=2, label='Aproximación spline')
    plt.scatter(t_muestra, y_muestra, marker='o', label='12 puntos de muestreo')
    plt.title("Modelado de respuesta transitoria de un sistema RLC")
    plt.xlabel("t")
    plt.ylabel("y(t)")
    plt.xlim(0, 6)
    plt.ylim(0, 15)
    plt.grid(True)
    plt.legend()
    plt.show()

# Llamada a la función principal
seccion2()