# Examen_MATEPORPC
# Alumno: Alan Yair Pérez Torres Y Osvaldo Villanueva Torres, Clave: 390030, 383628. Fecha: 2026-04-23
# 1.- Interpolación avanzada: Splines cúbicos e interpolación.

import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import CubicSpline

# Definir función original
def f(x):
    return 10 * (1 - np.exp(-2.25 * x)) * np.cos(2.222 * x)

# Tabla 1: muestreo de la respuesta RLC
def tabla1():
    X = np.array([0.0, 0.1, 0.25, 0.5, 0.75, 1.0, 1.41, 2.12, 2.83, 4.0, 5.0], dtype=float)
    Y = np.array([0.0000, 0.4292, 2.1162, 5.6133, 8.3122, 9.7900, 10.4153, 10.0860, 9.9827, 10.0004, 10.0001], dtype=float)
    return X, Y

# 1.- Grafica la función original, los puntos de la tabla y el spline cúbico
def graficar():
    X, Y = tabla1()

    # Crear spline cúbico natural
    cs = CubicSpline(X, Y, bc_type='natural')

    # Generar puntos para graficar
    x_new = np.linspace(0, 5, 400)
    y_new = cs(x_new)

    # Graficar
    plt.figure(figsize=(10, 6))
    plt.plot(x_new, f(x_new), label='Función original')
    plt.plot(X, Y, 'ro', label='Puntos de la tabla')
    plt.plot(x_new, y_new, label='Spline cúbico natural')
    plt.title('Comparación entre función original y spline cúbico natural')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.legend()
    plt.grid(True)
    plt.show()

    # Mostrar expresiones del primer y segundo intervalo
    print("\nCoeficientes del spline:")
    for i in range(2):
        a = cs.c[0, i]
        b = cs.c[1, i]
        c = cs.c[2, i]
        d = cs.c[3, i]
        xi = X[i]
        xf = X[i + 1]

        print(f"\nIntervalo [{xi}, {xf}]:")
        print(f"S_{i}(x) = {a:.10f}(x - {xi})^3 + {b:.10f}(x - {xi})^2 + {c:.10f}(x - {xi}) + {d:.10f}")

# Tabla 2: análisis de datos por interpolación
def tabla2():
    X = np.array([1.0, 1.2, 1.3, 2.0], dtype=float)
    Y = np.array([5.0, 4.0, 3.0, 8.4671], dtype=float)
    return X, Y

# 2.- Calcula error absoluto y relativo en x = 1.3
def calcular_errores():
    X, Y = tabla2()

    # Asegura orden ascendente por si acaso
    idx = np.argsort(X)
    X = X[idx]
    Y = Y[idx]

    # Valor real
    y_real = f(1.3)

    # Interpolación con spline natural
    cs = CubicSpline(X, Y, bc_type='natural')
    y_interpolado = cs(1.3)

    # Errores
    error_absoluto = abs(y_real - y_interpolado)
    error_relativo = error_absoluto / abs(y_real)

    print("\nAnálisis en x = 1.3")
    print(f"Valor real de y(1.3): {y_real:.10f}")
    print(f"Valor interpolado de y(1.3): {y_interpolado:.10f}")
    print(f"Error absoluto: {error_absoluto:.10f}")
    print(f"Error relativo: {error_relativo:.10f}")

# Programa principal
graficar()
calcular_errores()
#Obtener el MSE (Error cuadrático medio) es decir el error global de la representación spline de nuestro modelo RLC.
def calcular_mse():
    X, Y = tabla1()

    # Valor real para cada punto de la tabla
    y_real = f(X)

    # Interpolación con spline natural
    cs = CubicSpline(X, Y, bc_type='natural')
    y_interpolado = cs(X)

    # Calcular MSE
    mse = np.mean((y_real - y_interpolado) ** 2)

    print(f"\nError cuadrático medio (MSE) para la tabla 1: {mse:.10f}")
calcular_mse()

