import numpy as np
import math

def diferencias_divididas(x, y):
    n = len(y)
    coef = np.zeros([n, n])
    coef[:,0] = y
    for j in range(1, n):
        for i in range(n - j):
            coef[i][j] = (coef[i+1][j-1] - coef[i][j-1]) / (x[i+j] - x[i])
    return coef

def derivada_interpolante_cuadratica(x_nodos, y_nodos, x_eval):
    dd = diferencias_divididas(x_nodos, y_nodos)
    f_x0_x1 = dd[0, 1]
    f_x0_x1_x2 = dd[0, 2]
    x0, x1 = x_nodos[0], x_nodos[1]
    return f_x0_x1 + f_x0_x1_x2 * (2 * x_eval - x0 - x1)

def f_7(x):
    return 2 * x * math.cos(2 * x)

def df_7_exacta(x):
    return 2 * math.cos(2 * x) - 4 * x * math.sin(2 * x)

x_target_7 = 2.0
h = 0.1

nodos_adelante = [2.0, 2.0 + h, 2.0 + 2*h]
nodos_atras = [2.0 - 2*h, 2.0 - h, 2.0]
nodos_central = [2.0 - h, 2.0, 2.0 + h]

aprox_adelante = derivada_interpolante_cuadratica(nodos_adelante, [f_7(x) for x in nodos_adelante], x_target_7)
aprox_atras = derivada_interpolante_cuadratica(nodos_atras, [f_7(x) for x in nodos_atras], x_target_7)
aprox_central = derivada_interpolante_cuadratica(nodos_central, [f_7(x) for x in nodos_central], x_target_7)

valor_exacto_7 = df_7_exacta(x_target_7)

print("--- RESULTADOS EJERCICIO 8 ---")
print(f"Derivada Exacta en x=2.0: {valor_exacto_7:.6f}\n")
print(f"Error Real Hacia Adelante: {abs(valor_exacto_7 - aprox_adelante):.6f}")
print(f"Error Real Hacia Atrás:    {abs(valor_exacto_7 - aprox_atras):.6f}")
print(f"Error Real Central:        {abs(valor_exacto_7 - aprox_central):.6f}")