import numpy as np
import math
import matplotlib.pyplot as plt

def diferencias_divididas(x, y):
    n = len(y)
    coef = np.zeros([n, n])
    coef[:,0] = y
    for j in range(1, n):
        for i in range(n - j):
            coef[i][j] = (coef[i+1][j-1] - coef[i][j-1]) / (x[i+j] - x[i])
    return coef

def derivada_interpolante_cuadratica(x_nodos, y_nodos, x_eval):
    dd = diferencias_divididas(x_nodos, y_nodos)
    f_x0_x1 = dd[0, 1]
    f_x0_x1_x2 = dd[0, 2]
    x0, x1 = x_nodos[0], x_nodos[1]
    return f_x0_x1 + f_x0_x1_x2 * (2 * x_eval - x0 - x1)

def f_11(x):
    return 1 + math.log10(x)

def df_11_exacta(x):
    return 1 / (x * math.log(10))

x_vals_14 = [0.21, 0.22, 0.23, 0.24, 0.25, 0.26, 0.27]
errores_14 = []

tabla_nodos = np.arange(0.18, 0.31, 0.01) 
tabla_y = [f_11(x) for x in tabla_nodos]

for x_val in x_vals_14:
    idx_cercano = np.argmin(np.abs(tabla_nodos - x_val))
    nodos_optimos = tabla_nodos[idx_cercano-1 : idx_cercano+2]
    y_optimos = tabla_y[idx_cercano-1 : idx_cercano+2]
    
    aprox = derivada_interpolante_cuadratica(nodos_optimos, y_optimos, x_val)
    exacto = df_11_exacta(x_val)
    errores_14.append(abs(exacto - aprox))

min_error = min(errores_14)
idx_min = errores_14.index(min_error)

print("--- RESULTADOS EJERCICIO 14 ---")
print(f"El error mínimo ocurre en x = {x_vals_14[idx_min]} con un error de {min_error:.6e}")

plt.figure(figsize=(8, 5))
plt.plot(x_vals_14, errores_14, marker='o', linestyle='-', color='r')
plt.title('Error de Aproximación en función de $x_i$')
plt.xlabel('$x_i$')
plt.ylabel('Error Real')
plt.grid(True)
plt.show()