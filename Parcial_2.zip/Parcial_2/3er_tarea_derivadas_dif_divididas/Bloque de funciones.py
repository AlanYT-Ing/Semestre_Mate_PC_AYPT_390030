import numpy as np
import math
import matplotlib.pyplot as plt

def diferencias_divididas(x, y):
    """Calcula la tabla de diferencias divididas."""
    n = len(y)
    coef = np.zeros([n, n])
    coef[:,0] = y
    
    for j in range(1,n):
        for i in range(n-j):
            coef[i][j] = (coef[i+1][j-1] - coef[i][j-1]) / (x[i+j] - x[i])
            
    return coef

def derivada_interpolante_cuadratica(x_nodos, y_nodos, x_eval):
    """
    Aproxima la derivada en x_eval usando un polinomio cuadrático 
    (3 puntos) basado en la fórmula de Newton.
    P'(x) = f[x0,x1] + f[x0,x1,x2]*(2x - x0 - x1)
    """
    dd = diferencias_divididas(x_nodos, y_nodos)
    f_x0_x1 = dd[0, 1]
    f_x0_x1_x2 = dd[0, 2]
    
    x0, x1 = x_nodos[0], x_nodos[1]
    derivada = f_x0_x1 + f_x0_x1_x2 * (2 * x_eval - x0 - x1)
    
    return derivada