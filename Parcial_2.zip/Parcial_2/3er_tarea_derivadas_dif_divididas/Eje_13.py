import numpy as np
import math

def diferencias_divididas(x, y):
    n = len(y)
    coef = np.zeros([n, n])
    coef[:,0] = y
    for j in range(1, n):
        for i in range(n - j):
            coef[i][j] = (coef[i+1][j-1] - coef[i][j-1]) / (x[i+j] - x[i])
    return coef

def derivada_interpolante_cuadratica(x_nodos, y_nodos, x_eval):
    dd = diferencias_divididas(x_nodos, y_nodos)
    f_x0_x1 = dd[0, 1]
    f_x0_x1_x2 = dd[0, 2]
    x0, x1 = x_nodos[0], x_nodos[1]
    return f_x0_x1 + f_x0_x1_x2 * (2 * x_eval - x0 - x1)

def f_11(x):
    return 1 + math.log10(x)

def df_11_exacta(x):
    return 1 / (x * math.log(10))

x_target_11 = 0.268
nodos_11 = [0.26, 0.27, 0.28] 
y_nodos_11 = [f_11(x) for x in nodos_11]

# Aplicamos el redondeo
decimales_redondeo = 4
y_nodos_redondeados = [round(y, decimales_redondeo) for y in y_nodos_11]

aprox_13 = derivada_interpolante_cuadratica(nodos_11, y_nodos_redondeados, x_target_11)
valor_exacto_11 = df_11_exacta(x_target_11)
error_real_13 = abs(valor_exacto_11 - aprox_13)

print("--- RESULTADOS EJERCICIO 13 ---")
print(f"Aproximación con datos redondeados: {aprox_13:.6f}")
print(f"Error Real propagado por redondeo: {error_real_13:.6e}")