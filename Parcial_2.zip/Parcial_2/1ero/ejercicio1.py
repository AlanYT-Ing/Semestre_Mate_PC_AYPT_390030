import numpy as np
#Creamos una matriz
np.set_printoptions(precision=2, suppress=1, floatmode="fixed")


'''
A = np.array([[1,2,3,4], [-2,4,-3,5], [-1,3,-3,4]])

print ("A = ")
print(A)


#Obtenemos el tamaño de A
m,n = np.shape(A)
print("filas = {}, columnas = {}" .
format(m,n))

#accedemos a la segunda fila y tercera columna
a23 = A[1,2]
print("El valor de la segunda fila con tercera columna es ", a23)

#Encontramos la tercera fila de la matriz
fila3 = A[2,:]
print("La tercera fila es ", fila3)

#Encontramos la segunda columna de la matriz
columna2 = A[:,1]
print("La columna 2 es", columna2)

'''

'''

#operaciones: suma y resta

x = np.array([[1,2], [3,4]])
y = np.array([[-1,3], [2,-5]])

print("x = ")
print(x)

print("y = ")
print(y)

#Hacemos la suma de x y y
suma = x + y 
print("La suma de x con y es: ")
print(suma)

#Hacemos la resta de x y y
resta = x - y 
print("La resta de x con y es: ")
print(resta)

#Hacemos la multiplicación de x y y
multi = x * y 
print("La multiplicación de x con y es: ")
print(multi)

#Hacemos la división de x y y
div = x / y 
print("La división de x con y es: ")
print(div)


#Multiplicación escalar por una matriz
escalar = 10
x = np.array([[1,2], [3,4]])
multiesc = escalar*x

print("La multiplicación de x con el escalar es: ")
print(multiesc)

'''
#Producto punto de matrices (Frobenius)
x = np.array([[-1,-1], [7,7]])
y = np.array([[6,1], [4,7]])
print("x = ")
print(x)
print("y = ")
print(y)
#Hacemos el producto punto de x y y
prod_frobenius = np.sum(x * y)
# o también:
prod_frobenius = np.tensordot(x, y, axes=2)
# o equivalente:
prod_frobenius = np.trace(x.T @ y)
print("El producto punto de x con y es: ")
print(prod_frobenius)

